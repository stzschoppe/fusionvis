Version 1.0 BattleSimVis

Zum Starten

Win32/64 --> BattleSimVis.bat ausfuehren

Linux32 --> BattleSimBis.sh ausfuehrbar machen und anschlie�end starten

Linux64 --> BattleSimBis64.sh ausfuehrbar machen und anschlie�end starten


Getestet wurde diese Version mit Windows Vista 32Bit und Ubuntu 9.10 32Bit