#!/bin/sh

java -Djava.library.path=./BattleSimVis_lib/native -jar BattleSimVis.jar