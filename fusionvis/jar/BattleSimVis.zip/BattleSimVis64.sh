#!/bin/sh

java -Djava.library.path=./BattleSimVis_lib/native64 -jar BattleSimVis.jar